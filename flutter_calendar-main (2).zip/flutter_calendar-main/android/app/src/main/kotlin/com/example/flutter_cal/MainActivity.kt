package com.example.flutter_cal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
